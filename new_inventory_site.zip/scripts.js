document.addEventListener('DOMContentLoaded', () => {
    const inventoryForm = document.getElementById('inventory-form');
    const inventoryList = document.getElementById('inventory-list');
    const salesForm = document.getElementById('sales-form');
    const salesList = document.getElementById('sales-list');

    inventoryForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('product-name').value;
        const quantity = document.getElementById('product-quantity').value;

        const li = document.createElement('li');
        li.textContent = `${name} - Quantity: ${quantity}`;
        inventoryList.appendChild(li);

        inventoryForm.reset();
    });

    salesForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const product = document.getElementById('sale-product').value;
        const quantity = document.getElementById('sale-quantity').value;

        const li = document.createElement('li');
        li.textContent = `${product} - Sold: ${quantity}`;
        salesList.appendChild(li);

        salesForm.reset();
    });
});
